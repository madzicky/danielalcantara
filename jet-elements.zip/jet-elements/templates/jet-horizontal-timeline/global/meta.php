<?php
/**
 * Meta item template
 */

echo $this->_loop_item( array( 'item_meta' ), '<div class="jet-hor-timeline-item__meta">%s</div>' );
