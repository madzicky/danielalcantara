<?php
/**
 * Posts not found template
 */
?>
<h3 class="jet-posts__not-found"><?php esc_html_e( 'Posts not found', 'jet-elements' ); ?></h3>
